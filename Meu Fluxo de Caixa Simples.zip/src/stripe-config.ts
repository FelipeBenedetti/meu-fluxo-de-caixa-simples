export const STRIPE_PRODUCTS = {
  MEU_FLUXO_DE_CAIXA_SIMPLES: {
    priceId: 'price_1RSS2YP7h2x5c19KbaAhDWA2',
    name: 'MEU FLUXO DE CAIXA SIMPLES',
    description: 'ASSINATURA MENSAL MEU FLUXO DE CAIXA SIMPLES',
    mode: 'subscription' as const,
  },
} as const;